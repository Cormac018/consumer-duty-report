# Board Deck Design System

A working design system tuned specifically for **Uinsure's monthly Board updates**. Derived from the **Visual Identity Guidelines (30.01.2026)** but restrained for board context: a tighter palette, denser data, and a gravitas-first tone.

> **Primary use.** Monthly Board Update decks, mixed audience (internal directors + external observers — investors, advisers, partners). One-off strategic decks follow the same rules.

---

## Index

| File | What it's for |
| --- | --- |
| `README.md` | This file — the board-deck system (rules, tone, structure) |
| `SKILL.md` | Agent Skill frontmatter so this pack can be reused in Claude Code |
| `styles.css` | Root entry point — `@import`s the three CSS files below in one tag |
| `colors_and_type.css` | Design tokens — board palette is a strict subset |
| `fonts/` | Proxima Nova family (Light / Semibold / Extrabold / Black + italics) |
| `assets/` | Logos, headline lockup, U wallpaper; `assets/icons/{circled,amethyst,white,floating}/` PNG icon suite |
| `preview/` | Static HTML preview/specimen cards for the Design System tab (colours, type, spacing, brand, components, charts) |
| `slides/` | `TitleSlide.jsx` + `BoardTitleSlide.jsx` cover components (loaded as plain `<script type="text/babel">` globals — not ES exports, so live text-editing + Tweaks keep working in the browser Babel transform), `board-components.css`, `slides.css`, `deck-stage.js` web component |
| `samples/` | "Board pack - full sample.html" — a full monthly board update demonstrating the rules end-to-end |
| `ui_kits/marketing/` | Marketing site kit (`components.jsx` + `index.html`) — **not used for board decks**; kept for reference |

## Sources

- **`uploads/brand_guidelines.pdf`** — 27-page Visual Identity Guidelines dated 30.01.2026 (primary source).
- **`fonts/Proxima_Nova_*.otf`** + **`ProximaNova-*.ttf`** — primary typeface.
- Public site **[uinsure.co.uk](https://uinsure.co.uk)** — product surface, customer copy.
- **GitHub — [Cormac018/Uinsure-Board-Design](https://github.com/Cormac018/Uinsure-Board-Design)** — the working repo this design system was built from. Explore it directly for anything not captured here (it's the same source, so it should stay in sync).

---

## THE BOARD BRIEF — how board decks differ

**Audience.** Mixed: directors and execs internally, plus the occasional external observer (investor, partner, adviser). Assume **financially literate**, time-poor, and reading the deck before the meeting. Write for the read-aloud and the read-alone.

**Tone.** Restrained. Confident, measured, factual. The marketing voice (playful punchlines, all-caps social headlines) **does not belong here**. Board context demands gravitas.

**The three words.** **Smart. Clear. Concise.**
- *Smart* — only insight, never recap. If it's in the appendix or pre-read, don't repeat it on a slide.
- *Clear* — one idea per slide, one number per stat. Headlines say the conclusion, not the topic.
- *Concise* — fewer words than feel comfortable. If a sentence can be cut, cut it.

**Cadence.** Monthly. The Board sees the same chart shapes month after month — keep series colours, axes, and definitions stable.

**Confidentiality.** Every page must carry the classification line in the bottom margin (e.g. **"Strictly Confidential — Board Only"** or **"Strictly Confidential — Board & Observers"**). See *Classification* below.

**Writing rules.**
- Headlines are **conclusions**, not topics. ✗ "Q1 revenue." ✓ "Q1 revenue beat plan by 8%."
- One stat per row in tables; round to the nearest meaningful unit; show variance vs plan and vs prior period.
- Every chart has: a conclusion title, axis labels with units, source/footnote, and as-of date.
- No emoji. No exclamation marks. No "we're excited to share…". No marketing-flavoured punchlines.
- Spell out acronyms on first use (GWP, NPS, CAC).
- Numbers: thousands separators, `£` not "GBP" for sterling, dates in `DD Mon YYYY` long-form.

---

## VISUAL FOUNDATIONS

### Colour — strictly restricted for Board

The board palette is a **subset** of the brand palette. The secondary spectrum (Nebula, Dark Nebula, Blue Sky, Supernova Rose, Photon, the lighter amethyst tints) is **excluded** from board decks. The board reads in three colours:

| Token | Hex | Role |
| --- | --- | --- |
| **Dark Amethyst** `--uin-dark-amethyst` | `#331047` | Headlines, ink, primary chart series, U wallpaper. |
| **Aurora Green** `--uin-aurora-green` | `#23F3A1` | Accent only — positive deltas, KPI callouts, section markers. Never decorative. |
| **Starlight White** `--uin-starlight-white` | `#FFFFFF` | Page surface, type on dark. |

**Allowed neutrals** (functional only — hairlines, table rows, muted captions):

| Token | Hex | Role |
| --- | --- | --- |
| `--uin-board-ink-muted` | `#5C5C5C` | Captions, footnotes, axis labels. |
| `--uin-board-hairline` | `#E5E5E5` | Table borders, dividers. |
| `--uin-board-row-alt` | `#F7F7F8` | Zebra-stripe table rows. |
| `--uin-board-negative` | `#B73E5B` | Negative deltas in tables/charts (use sparingly). |

**Rules — no exceptions:**
- No light purple. No nebula tints. No multi-stop gradients (Mixed Amethyst, Mixed Nebula, etc.). No Blue Sky / Photon / Supernova accents.
- Aurora Green is **accent only** — never a fill for a whole page area, never decorative. Reserve it for the moment you want the eye to land.
- Negative numbers in a table: `--uin-board-negative` text, no fill.
- Charts: primary series Dark Amethyst, secondary Aurora Green, tertiary `--uin-board-ink-muted`. That's it. If you need a fourth series, the chart is too dense — split it.

### Typography

- **Proxima Nova** throughout — Black (900) for slide titles and stat numbers, Semibold (600) for chart labels and table headers, Light (300) for body and lede.
- Don't alter tracking or kerning. Don't use Black for body — it doesn't read.
- Minimum sizes on a 1920×1080 slide: title ≥56px, body ≥22px, table cell ≥20px, footnote/caption ≥16px.
- Line length: 9–10 words max for headlines, 60–72 chars for body.

### U wallpaper

`assets/brand-background-u.jpg` is the **only approved U background** — a full-bleed 1920×1080 amethyst-on-amethyst image. Used for the cover, section dividers, and the closer. Don't hand-roll a U with CSS or recolour the shape.

> **Text colour on the U wallpaper — non-negotiable.** Amethyst-on-amethyst means only **Starlight White `#FFFFFF`** and **Aurora Green `#23F3A1`** pass contrast. Never use Dark Amethyst or any neutral grey for type, icons, or logo lockups on this background. The amethyst Uinsure logo and amethyst headline lockup **must** be swapped for their white variants. Use the semantic CSS tokens `--uin-on-u-wallpaper-fg` (white) and `--uin-on-u-wallpaper-accent` (aurora) so this can't drift.

### Logos and headlines

PNG masters, always:

| File | When |
| --- | --- |
| `assets/logo-uinsure-amethyst.png` | Default — every light page. |
| `assets/logo-uinsure-white.png` | On the U wallpaper / dark surfaces. |
| `assets/headline-insurance-was-complicated-amethyst.png` | Cover & footer mark on light. |
| `assets/headline-insurance-was-complicated-white.png` | Cover & footer mark on dark. |

### Footer marks — required on every page except the cover

Every content page (including section dividers, KPI pages, closers — everything except the title cover) carries two marks at the bottom edge:

- **Bottom-LEFT:** Uinsure logo.
- **Bottom-RIGHT:** the "Insurance was complicated. We redesigned it." headline lockup.

**Sizing** (headline ≈ 1.5× logo height):

| Surface | Logo height | Headline height |
| --- | --- | --- |
| 16:9 slide (1920×1080) | 72–88 px | 110–132 px |
| A4 document / letter | 40–48 px | 60–72 px |

Keep both inside the standard 40%-of-logo-width exclusion zone. Don't tint, don't outline, don't mix amethyst-on-dark or white-on-light.

### Classification line

Every page (yes, including the cover) carries a small classification line in the bottom margin — **centred** between the footer marks, or just above them. Default phrasing:

> **STRICTLY CONFIDENTIAL — BOARD ONLY** *(or)* **STRICTLY CONFIDENTIAL — BOARD & OBSERVERS**

Set in Proxima Nova Semibold, **14–16px**, letter-spaced (`0.12em`), `--uin-board-ink-muted` on light or 60%-opacity white on dark. The classification phrasing is set at the top of the deck and is identical on every slide.

### Page numbers and meeting metadata

Top-right corner of every content page (not the cover): `MM YYYY · Page N of N`, in Proxima Nova Semibold 16px, `--uin-board-ink-muted`. The cover carries the same metadata as part of the title lockup, not in the corner.

### Spacing & layout

- Slide canvas: 1920×1080 design space, scale-to-fit via `deck-stage`.
- Page margins on content slides: 168px L/R, 96px top, 200–230px bottom (the footer mark zone is reserved).
- Grid: a 12-column grid at 1920px works (column 124px, gutter 24px).
- Logo exclusion zone = 40% of logo width on every side. Non-negotiable.

### Cards, hairlines, shadows

- Cards: white surface, 12–16px radius, **1px `--uin-board-hairline` border** preferred over shadow for board context (cleaner print).
- If a shadow is needed: `0 2px 6px rgba(51, 16, 71, 0.08)` only. No glow effects.
- Tables: 1px hairline borders, 12px cell padding, zebra-stripe with `--uin-board-row-alt`. Header row: Proxima Nova Semibold, `--uin-dark-amethyst` on `--uin-board-row-alt`.

---

## SHARED COMPONENTS — `slides/board-components.css`

Board decks share a single component library. Import it in every new board deck:

```html
<link rel="stylesheet" href="../colors_and_type.css" />
<link rel="stylesheet" href="../slides/slides.css" />
<link rel="stylesheet" href="../slides/board-components.css" />
```

`board-components.css` is the **single source of truth** for chrome, layout primitives, commentary patterns, charts, KPI tiles, tables, status pills, and content components (agenda, declarations, minutes, milestones, decisions, calendar, appendix). Edit here, not in individual decks. Per-deck `<style>` blocks should hold only deck-specific overrides.

---

## LAYOUT PRIMITIVES — the `.layout` system

Every content slide uses the same three-zone layout. This is what prevents the **"H1 crammed at the top with empty whitespace below"** failure mode.

```html
<div class="slide-light">
  <div class="uin-pagenum">May 2026 · Page N of M</div>
  <div class="layout centred">
    <div class="head">
      <div class="eyebrow">Section · 02.3 financial review</div>
      <h2 class="title">Headline as a conclusion.</h2>
      <p class="lede muted">Optional one-line lede.</p>
    </div>
    <div class="body">
      <!-- chart / table / cards go here — fills the remaining vertical space -->
    </div>
  </div>
  <div class="uin-classify">…</div>
  <div class="uin-footer-mark">…</div>
</div>
```

**Variants — pick one per slide:**

| Class | Body alignment | Use for |
| --- | --- | --- |
| `.layout` (default) | Top-aligned | Dense slides with full-bleed charts that need height (line / bar / stacked / heatmap). |
| `.layout.centred` | Vertically centred | Sparse slides where content is shorter than the available space — declarations, action tracker, milestones, financials table, AOB, decision card. |
| `.layout.spread` | `space-between` | Slides with two stacked blocks that should distribute (headlines: highlight strip + KPI row). |

**Spacing contract — don't override:**
- `padding: 144px 168px 230px;` (top / sides / bottom). The 230px bottom reserves the footer-mark zone — never put content there.
- `gap: 36px` between `.head` and `.body`.
- `.head` is content-height; `.body` is `flex: 1` and fills.

---

## COMMENTARY PATTERNS — three patterns, agent picks per slide

Board slides usually pair a visual with explanatory commentary. Three canonical patterns; pick the one that fits the data shape.

### A) Highlight strip — `.highlights`

Three short bordered bullets across the top of a slide, above the main visual.

**Use when** the slide opens a section or summarises a state in three clean beats — "top line / watch / decision", or "what / so what / now what". Each bullet is one short sentence, max ~8 words.

```html
<div class="highlights">
  <div class="highlight">
    <div class="label">Top line</div>
    <div class="text">GWP £18.4m, +12% vs plan.</div>
  </div>
  <div class="highlight neg">
    <div class="label">Watch</div>
    <div class="text">Retention −1.4pp MoM, 2023 cohort.</div>
  </div>
  <div class="highlight">
    <div class="label">Decision</div>
    <div class="text">Q3 panel re-pricing — page 18.</div>
  </div>
</div>
```

Modifiers: `.neg` (negative-coloured border) and `.muted` (grey border).

### B) Right-rail commentary — `.with-rail`

Chart 2/3 left, commentary card 1/3 right. The board's workhorse pattern.

**Use when** the chart needs explanation that lands in an ask — "what changed / what to watch / asked of the Board". Each `.block` is ~2 lines; one `.ask` closer at the bottom in the row-alt panel.

```html
<div class="with-rail">           <!-- 1fr + 360px -->
  <div class="chart-card">…</div>
  <div class="rail">
    <div class="block"><h3>What changed</h3><p>…</p></div>
    <div class="block"><h3>What to watch</h3><p>…</p></div>
    <div class="block"><div class="ask"><b>Asked of the Board:</b> …</div></div>
  </div>
</div>
```

Variant: `.with-rail.wide-rail` gives the commentary 480px instead of 360px (use when commentary is heavier than the chart).

### C) Pinned callout — `.callout` on `.chart-with-callouts`

A small bordered card overlaid on the chart at a specific data point.

**Use when** one or two specific moments on a chart need labelling — a peak, a trough, an inflection point, a forecast. Never more than two per chart.

```html
<div class="chart-with-callouts">
  <svg viewBox="…">…</svg>
  <div class="callout muted" style="left: 18%; top: 8%;">
    <b>Aug 2025 peak.</b> 87.4% — last month above target.
  </div>
  <div class="callout neg" style="right: 4%; top: 36%;">
    <b>May 2026.</b> 84.2% (−1.4pp MoM). Remediation on page 14.
  </div>
</div>
```

Modifiers: `.neg`, `.muted`. Position with `left/right/top` in percentages so callouts move with the chart.

**Choosing between the three:**

| Pattern | When to use | Don't use when |
| --- | --- | --- |
| Highlight strip | Section opener / exec summary that needs three beats. | The data needs explanation longer than 8 words. |
| Right-rail | The slide ends in an ask, or the commentary is longer than two short sentences. | The slide has a section opener vibe — use the strip. |
| Pinned callouts | One or two specific data points carry the story. | The whole chart is the story (use right-rail instead). |

---

## DATA DENSITY — charts, tables, footnotes

The board deck stands or falls on its data. Rules:

**Charts.**
- Title is the **conclusion in plain English**, not the topic. "GWP up 12% MoM, ahead of plan" — not "Gross Written Premium".
- Subtitle states the *as-of date* and the *vs comparison* ("vs March plan", "vs same month last year").
- One y-axis, never two. If you need two scales, split the chart.
- Series order: most important first. Colour: Dark Amethyst primary, Aurora Green secondary, `--uin-board-ink-muted` tertiary. Same colour for the same series every month.
- Axis labels carry units (£m, %, days, count). No abbreviations the board doesn't already know.
- Source/footnote bottom-left in 14px `--uin-board-ink-muted`.
- No 3D, no shadows on bars, no gridlines other than horizontals at major ticks.

**Tables.**
- Max 6 columns and 8 rows visible at once. If you need more, it's a pre-read appendix, not a slide.
- Numeric columns: right-aligned, tabular-nums, thousands separators.
- Variance columns: show both absolute and percent, with sign. Negative in `--uin-board-negative`. Positive **does not need green** — restraint matters.
- Header row in Semibold; body row Light. Hairline borders only, no full grid.

**Footnotes.**
- Numeric superscripts in body; resolve at the bottom of the slide in 14px `--uin-board-ink-muted`. Define every non-obvious term once.
- Source attribution mandatory for external figures.

**KPI tiles.**
- One number per tile. Number in Proxima Nova Black, 80–120px. Label below in Semibold 22px. Variance line below the label: small arrow + percent in `--uin-aurora-green` (positive) or `--uin-board-negative` (negative).
- Never more than 4 KPI tiles per row.

### Chart-type catalog — pick the right shape for the question

Seven shapes covering most board questions. **Every chart uses the same colour contract:** Dark Amethyst primary, Aurora Green secondary, `--uin-board-ink-muted` tertiary. Same colour for the same series, every month.

| Chart | CSS handle | Use it for | Don't use for |
| --- | --- | --- | --- |
| **Grouped bar** | `.chart-card` + bar `<rect>`s in 2 colours | Two discrete series compared period-by-period (actual vs plan, this year vs last). The default for "vs plan" stories. | More than 3 series (becomes noisy); use stacked or small multiples. |
| **Stacked bar** | `.chart-card` + stacked `<rect>`s | Composition of a total over time (channel mix, product mix, cohort mix). Shows the total AND the shift. | When the components don't sum to a meaningful total (rates, ratios). |
| **Line** | `.chart-card` + `<polyline>` + dashed Aurora target line | Trend over time, especially against a target. Reserve for trajectory — does the slope go up, down, sideways? | Discrete period comparisons (use bars). |
| **Line + pinned callouts** | `.chart-with-callouts` overlay | A line chart where 1–2 specific points carry the story (peak, latest, trough). | More than 2 callouts — the chart becomes unreadable. |
| **Sparkline row** | `.kpi.sparkline` with inline `<svg>` | KPI grid where each tile needs to show its 12-month trajectory under the headline number. Read slope, not magnitude. | A standalone trend story — promote to a full line chart. |
| **Waterfall (variance bridge)** | `.chart-card` + step `<rect>`s | Plan → actual margin bridges, year-on-year EBITDA walks, anything that decomposes a change into named drivers. Favourable = Aurora, unfavourable = `--uin-board-negative`, anchors = Dark Amethyst. | When components don't add cleanly to the anchor (use a stacked bar). |
| **Donut (share of total)** | `.chart-card` + concentric `<circle>`s + `.donut-legend` | Composition at a single point in time — *and only 2–4 slices*. Centre carries the total. | More than 4 slices (use a horizontal bar). |
| **Cohort heatmap** | `.heat` grid with month columns | Retention / engagement by cohort × month-from-signup. Shows where in the cohort lifecycle the drag lives. | Anything that isn't cohort × time. |

**Rules of thumb:**
- One chart per slide. If you need two, you need two slides — or one chart and a right-rail of numbers.
- Always pair the chart with commentary (highlight strip, right-rail, or callouts) — a chart without explanation forces the board to interpret in real time.
- Sparkline rows can repeat across months unchanged; full charts should evolve only when the underlying period changes.
- Heatmaps need a fixed cell `height` (not `aspect-ratio`) on a slide — 44px on a 1080-tall slide keeps 7 rows + header inside the safe area.

---

## DECK STRUCTURE — what a monthly board update contains

A monthly board update is roughly 12–18 slides. The canonical structure:

1. **Cover** — `TitleSlide` (or `BoardTitleSlide` variant) on the U wallpaper. Carries deck title, board meeting date, classification line.
2. **Section divider — Headlines** (1 slide).
3. **Executive summary** — 3–5 bullets, what changed, what needs a decision (1 slide).
4. **Section divider — Performance** (1 slide).
5. **Financial performance** — GWP, revenue, EBITDA vs plan, vs LY (1–2 slides).
6. **Operational KPIs** — quote-to-bind, retention, NPS, claims SLAs (1–2 slides).
7. **Section divider — Strategy & risks** (1 slide).
8. **Strategy progress** — RAG status against quarterly milestones (1 slide).
9. **Risk register update** — top 3–5 risks, movement since last month (1 slide).
10. **Section divider — Decisions** (1 slide).
11. **Decisions required** — clear ask, recommendation, options considered (1 slide per decision).
12. **Closer** — next month's focus, dates, contact (1 slide on U wallpaper).

### Section dividers — required

Every grouped section is preceded by a **section divider slide**. Specs:

- Background: U wallpaper (`assets/brand-background-u.jpg`).
- **Alignment: left-aligned, vertically centred.** Section content sits in the left half of the canvas at the standard 168px left margin, with the block vertically centred against the slide. Never centre-align divider text horizontally — left-aligned text reads in the same rhythm as content slides.
- Small Aurora-green section number ("01", "02"…) on top; below it the section name in Proxima Nova Black, 96–112px, Starlight White; an optional single-line description in Light 28px, Starlight White below that.
- Footer marks: white variants (logo bottom-LEFT, headline lockup bottom-RIGHT).
- Classification line: white at 60% opacity, centred above the footer marks.
- No icons, no decoration on dividers. They are pause-and-breathe slides.

### Cover (BoardTitleSlide)

The board cover is a more restrained variant of the canonical `TitleSlide`:
- U wallpaper background.
- White Uinsure logo top-left.
- Aurora pill above title contains the meeting type: **"MONTHLY BOARD UPDATE"**.
- Title in two lines: line 1 in Aurora ("BOARD PACK"), line 2 in white (the period — e.g. "MAY 2026").
- Description: one short sentence, Light 28px. No marketing copy.
- Bottom-left: meeting date (`19 MAY 2026`).
- Bottom-right: the "Insurance was complicated" headline lockup is **omitted from the cover** (it's the hero on every other page).
- Classification line above the date, white at 60%.

---

## ICONOGRAPHY

**Use sparingly on board decks** — at most one icon per stat tile or section header, never as decoration.

| Folder | Treatment | When |
| --- | --- | --- |
| `assets/icons/circled/icon-NN.png` | Aurora-gradient circle | Default. KPI tiles, section markers. |
| `assets/icons/amethyst/icon-NN.png` | Solid Dark Amethyst | Print-friendly, single-colour appendix pages. |
| `assets/icons/white/icon-NN.png` | Solid white | Section dividers on U wallpaper. |

**Icon index → semantic name.** The source export names files by index only (`icon-36.png` … `icon-65.png`); visually confirming each glyph gives this mapping to the guideline's semantic list (same index across all three colour folders):

| # | Semantic name | Glyph | # | Semantic name | Glyph |
| --- | --- | --- | --- | --- | --- |
| 36 | `phone` | handset | 47 | `protected` | shield + house |
| 37 | `highly-rated` | star | 48 | `sustainable` | leaf |
| 38 | `security` | shield + check | 49 | `quick-referral` | stopwatch |
| 39 | `expert` | lightbulb | 50 | `quote-review` | pen |
| 40 | `sim` | SIM card | 51 | `included` | checkmark |
| 41 | `call-app` | phone/device outline | 52 | `document-form` | folder |
| 42 | `key` | key | 53 | `scan-qr` | scan corners |
| 43 | `cover` | umbrella | 54 | `email` | @ |
| 44 | `lightning-fast` | lightning bolt | 55 | `fees` | £ |
| 45 | `customer-service` | headset | 56 | `brand-u` | Uinsure U mark |
| 46 | `keyboard` | keyboard | 57 | `excluded` | X mark |

Icons 58–64 repeat the seven **floating** icons (below) rendered in the aurora-circle treatment, in the same order. Icon 65 is a bonus house/roof glyph with no guideline name — treat it as a spare `home` variant.

**Floating icons** (`assets/icons/floating/`, named semantically already): `device` · `payment` · `folder` · `quote-marks` · `scan` · `star` · `home`. Use the floating set only when the page already has a card or container framing the icon — not as standalone marks on board slides.

**Rules.**
- Always reference the PNGs from `assets/icons/`. Never hand-roll an SVG of a Uinsure glyph.
- Pick one treatment per deck — all circled, OR all monochrome. Don't mix.
- Sizing on a 1920 slide: 64–96px in body, up to 160px in hero KPI tiles. Never below 48px on a board slide.
- No emoji, ever.

---

## Do-nots — board edition

- Don't use light purple / nebula / lighter amethyst tints anywhere.
- Don't use the Mixed Amethyst, Mixed Nebula, Mixed Sky, Mixed Aurora, Mixed Nova gradients.
- Don't use Blue Sky, Photon, or Supernova accents.
- Don't place Dark Amethyst type or marks on the U wallpaper — use white or Aurora.
- Don't put more than 4 KPI tiles in a row or more than 6 columns in a table.
- Don't use Aurora as a decorative fill or for whole page areas — accent only.
- Don't drop the classification line, even on the cover.
- Don't use marketing punchlines ("we redesigned it", "loyalty like royalty") in slide body copy. The headline lockup carries the brand statement; the deck body stays factual.
- Don't put the headline lockup on the cover bottom — it's the hero up top.
- Don't shrink or recolour the U wallpaper, and don't substitute a hand-rolled U.
- Don't alter tracking/kerning on Proxima Nova.

---

## Reference: Brand voice (marketing surfaces)

This system is board-first. Marketing-voice rules (the playful Uinsure "Home Insurance was complicated, we redesigned it." persona) still apply to marketing, social, and customer comms — those live in `ui_kits/marketing/` and the original visual identity PDF. Board decks deliberately depart from that tone. If you're generating an adviser pack, customer letter, or social tile, look there instead.

---

## Caveats / asks to close the loop

1. **Live KPI definitions.** I've placeholder-named KPIs (GWP, NPS, quote-to-bind, etc.) — confirm the canonical set the board sees each month and I'll pin them in the sample deck.
2. **Classification phrasing.** I've gone with "STRICTLY CONFIDENTIAL — BOARD ONLY" / "BOARD & OBSERVERS". Confirm if Uinsure has standard legal wording for this.
3. **Aurora hover** `#10D487` and **board negative** `#B73E5B` are derived, not in the palette. Flag if you want canonical values.
4. **External PPTX template** — guideline p.19 says one is coming. When it lands, I'll align the slide-master EMU coords here.
