/* @ds-bundle: {"format":3,"namespace":"DesignSystem_62c276","components":[],"sourceHashes":{"doc-page.js":"7feb7a4009b0","slides/BoardTitleSlide.jsx":"927adc010081","slides/TitleSlide.jsx":"ec074c8626ba","slides/deck-stage.js":"522102a1c71e","ui_kits/marketing/components.jsx":"484dda71755c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_62c276 = window.DesignSystem_62c276 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// doc-page.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
/* BEGIN USAGE */
/**
 * <doc-page> — paged-document shell for printable HTML.
 *
 * On screen the document renders as a single continuous sheet on a desk
 * background (Google Docs' pageless view): you scroll one tall page card.
 * There is no manual page-splitting — write the whole document as normal
 * flow inside <doc-page> and the browser's print engine paginates it at
 * export.
 *
 * At print the component injects `@page { size: …; margin: 0 }` (which
 * leaves Chrome no margin box to draw its date/URL/page-count header in)
 * and moves the visual margin onto the sheet's own padding, so the printed
 * page has the same inset you see on screen. Standard break-hygiene rules
 * (`break-inside: avoid` on figures, code blocks, images and table rows;
 * `orphans/widows: 3`) are applied so paragraphs and groups split cleanly.
 *
 * Usage:
 *   <style>doc-page:not(:defined){visibility:hidden}</style>
 *   <doc-page size="letter" margin="0.75in">
 *     <h1>Title</h1>
 *     <p>…body…</p>
 *   </doc-page>
 *   <script src="doc-page.js"></script>
 *
 * Attributes:
 *   size    — letter | a4 | legal (default letter)
 *   width / height — explicit CSS lengths, override `size`
 *   margin  — printable inset on every page (default 0.75in)
 *
 * Running header/footer (optional): give an element `slot="header"` or
 * `slot="footer"` and it repeats on every printed page via
 * `position: fixed`. To keep body text from sliding under it, the
 * component prints inside a single-cell table whose <thead>/<tfoot> are
 * spacers sized to the header/footer height — browsers repeat thead/tfoot
 * on every page, so each sheet's content starts below the header and ends
 * above the footer. On screen the header/footer render once at the
 * top/bottom of the sheet.
 *
 * Author content as static HTML so the user can click-to-edit any text
 * directly. Do not set width/padding/background on the document body —
 * the component owns the sheet box.
 */
/* END USAGE */

(() => {
  const PAPER = {
    letter: ['8.5in', '11in'],
    a4: ['210mm', '297mm'],
    legal: ['8.5in', '14in']
  };
  const CSS_LENGTH = /^\d+(\.\d+)?(px|in|mm|cm|pt|pc)$/;
  const safeLen = (v, fb) => CSS_LENGTH.test((v || '').trim()) ? v.trim() : fb;
  const stylesheet = `
    :host {
      position: relative;
      display: block;
      min-height: 100vh;
      background: #ece8dd;
      padding: 48px 24px;
      box-sizing: border-box;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Arial, sans-serif;
      --doc-page-w: 8.5in;
      --doc-page-h: 11in;
      --doc-page-margin: 0.75in;
      --doc-hdr-h: 0px;
      --doc-ftr-h: 0px;
    }
    .sheet {
      width: var(--doc-page-w);
      margin: 0 auto;
      background: #fff;
      box-shadow: 0 2px 14px rgba(20, 20, 19, 0.12);
      border-radius: 2px;
      box-sizing: border-box;
      padding: var(--doc-page-margin);
    }
    .frame { width: 100%; border-collapse: collapse; }
    .frame td, .frame th { padding: 0; text-align: left; font-weight: inherit; }
    .hdr-space { height: var(--doc-hdr-h); }
    .ftr-space { height: var(--doc-ftr-h); }
    ::slotted([slot="header"]),
    ::slotted([slot="footer"]) { display: block; box-sizing: border-box; }
    @media print {
      :host { background: none; padding: 0; min-height: 0; }
      .sheet {
        width: auto; margin: 0; box-shadow: none; border-radius: 0;
        padding: 0 var(--doc-page-margin);
      }
      /* The thead/tfoot spacers repeat on every page, so they carry the
       * vertical page margin (which the sheet's own padding cannot, since
       * that padding is consumed once on the first/last page). The running
       * header/footer are fixed inside that band. */
      .hdr-space { height: max(var(--doc-page-margin), calc(var(--doc-hdr-h) + 0.35in)); }
      .ftr-space { height: max(var(--doc-page-margin), calc(var(--doc-ftr-h) + 0.35in)); }
      ::slotted([slot="header"]) {
        position: fixed; top: 0; left: 0; right: 0; margin: 0;
        padding: calc(var(--doc-page-margin) * 0.45) var(--doc-page-margin) 0;
      }
      ::slotted([slot="footer"]) {
        position: fixed; bottom: 0; left: 0; right: 0; margin: 0;
        padding: 0 var(--doc-page-margin) calc(var(--doc-page-margin) * 0.45);
      }
    }
  `;
  class DocPage extends HTMLElement {
    static get observedAttributes() {
      return ['size', 'width', 'height', 'margin'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._mo = typeof MutationObserver === 'function' ? new MutationObserver(() => this._scheduleMeasure()) : null;
    }
    get pageWidth() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()];
      return safeLen(this.getAttribute('width'), named ? named[0] : PAPER.letter[0]);
    }
    get pageHeight() {
      const named = PAPER[(this.getAttribute('size') || '').toLowerCase()];
      return safeLen(this.getAttribute('height'), named ? named[1] : PAPER.letter[1]);
    }
    get pageMargin() {
      return safeLen(this.getAttribute('margin'), '0.75in');
    }
    connectedCallback() {
      if (!this._sheet) this._render();
      this._syncSize();
      this._syncPrintPageRule();
      if (this._mo) this._mo.observe(this, {
        subtree: true,
        childList: true,
        characterData: true,
        attributes: true
      });
      this._onResize = () => this._scheduleMeasure();
      window.addEventListener('resize', this._onResize);
      if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(() => this._scheduleMeasure());
      }
      this._scheduleMeasure();
    }
    disconnectedCallback() {
      window.removeEventListener('resize', this._onResize);
      if (this._mo) this._mo.disconnect();
      if (this._raf) {
        cancelAnimationFrame(this._raf);
        this._raf = null;
      }
      // Drop the head rule when the last doc-page leaves, so a deleted
      // document's @page geometry can't apply to whatever replaces it.
      if (!document.querySelector('doc-page')) {
        const tag = document.getElementById('doc-page-print');
        if (tag) tag.remove();
      }
    }
    attributeChangedCallback() {
      if (!this._sheet) return;
      this._syncSize();
      this._syncPrintPageRule();
      this._scheduleMeasure();
    }
    _render() {
      this._root.innerHTML = `
        <style>${stylesheet}</style>
        <style id="vars"></style>
        <div class="sheet" data-screen-label="Document">
          <table class="frame" role="presentation">
            <thead><tr><th><div class="hdr-space"><slot name="header"></slot></div></th></tr></thead>
            <tbody><tr><td class="body"><slot></slot></td></tr></tbody>
            <tfoot><tr><td><div class="ftr-space"><slot name="footer"></slot></div></td></tr></tfoot>
          </table>
        </div>`;
      this._sheet = this._root.querySelector('.sheet');
      this._vars = this._root.getElementById('vars');
    }

    /** Runtime sizing lives in a shadow <style> :host rule, never on the
     *  light-DOM host element, so serialize-persist can't write it back. */
    _syncSize(hdrH, ftrH) {
      this._vars.textContent = ':host{' + '--doc-page-w:' + this.pageWidth + ';' + '--doc-page-h:' + this.pageHeight + ';' + '--doc-page-margin:' + this.pageMargin + ';' + '--doc-hdr-h:' + (hdrH || 0) + 'px;' + '--doc-ftr-h:' + (ftrH || 0) + 'px}';
    }

    /** @page is a no-op inside shadow DOM, so the rule lives in <head>.
     *  Re-appended on every sync so it stays last in source order — the
     *  @page cascade is source-order per descriptor, so this rule wins
     *  over any other @page rule in the document. */
    _syncPrintPageRule() {
      const id = 'doc-page-print';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
      }
      document.head.appendChild(tag);
      tag.textContent = '@page { size: ' + this.pageWidth + ' ' + this.pageHeight + '; margin: 0; } ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; height: auto !important; overflow: visible !important; } ' + 'h1,h2,h3,h4,h5,h6 { break-after: avoid; } ' + 'figure,pre,blockquote,img,svg,tr { break-inside: avoid; } ' + 'p,li { orphans: 3; widows: 3; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; } ' + '*, *::before, *::after { animation-delay: -99s !important; animation-duration: .001s !important; ' + 'animation-iteration-count: 1 !important; animation-fill-mode: both !important; ' + 'animation-play-state: running !important; transition-duration: 0s !important; } }';
    }
    _scheduleMeasure() {
      if (this._raf) return;
      this._raf = requestAnimationFrame(() => {
        this._raf = null;
        this._measure();
      });
    }

    /** Slot heights feed the print spacers (--doc-hdr-h / --doc-ftr-h), so
     *  they re-measure on content mutation, resize, and font load. */
    _measure() {
      const hdr = this.querySelector(':scope > [slot="header"]');
      const ftr = this.querySelector(':scope > [slot="footer"]');
      this._syncSize(hdr ? hdr.offsetHeight : 0, ftr ? ftr.offsetHeight : 0);
    }
  }
  if (!customElements.get('doc-page')) {
    customElements.define('doc-page', DocPage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "doc-page.js", error: String((e && e.message) || e) }); }

// slides/BoardTitleSlide.jsx
try { (() => {
/*
 * BoardTitleSlide — restrained cover for monthly Board updates.
 *   • U wallpaper background (assets/brand-background-u.jpg)
 *   • White Uinsure logo top-left
 *   • Aurora pill: deck type / context (e.g. "MONTHLY BOARD UPDATE")
 *   • Two-line headline: aurora first line, white second line
 *   • Short Light description
 *   • Meeting date bottom-left, classification line bottom-right
 *   • NO "Insurance was complicated" headline lockup — title is the hero
 *
 * Live-editable: click any text in the slide, or toggle Tweaks in the toolbar.
 */
const {
  useState,
  useEffect,
  useRef
} = React;
const BOARD_TITLE_DEFAULTS = /*BOARD-EDITMODE-BEGIN*/{
  "context": "MONTHLY BOARD UPDATE",
  "headlineAurora": "BOARD PACK",
  "headlineWhite": "MAY 2026",
  "description": "Performance against plan, strategic milestones, and decisions required for the May meeting.",
  "date": "19 MAY 2026",
  "classification": "STRICTLY CONFIDENTIAL — BOARD ONLY"
} /*BOARD-EDITMODE-END*/;
function BoardEditable({
  value,
  onChange,
  className,
  style,
  uppercase = false,
  placeholder
}) {
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current && ref.current.textContent !== value) {
      ref.current.textContent = value;
    }
  }, [value]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    className: className,
    style: {
      ...style,
      textTransform: uppercase ? "uppercase" : undefined,
      outline: "none",
      cursor: "text"
    },
    contentEditable: true,
    suppressContentEditableWarning: true,
    spellCheck: false,
    "data-placeholder": placeholder,
    onInput: e => onChange(e.currentTarget.textContent || ""),
    onKeyDown: e => {
      if (e.key === "Enter") {
        e.preventDefault();
        e.currentTarget.blur();
      }
    }
  });
}
const BoardTitleSlide = ({
  initial = BOARD_TITLE_DEFAULTS
} = {}) => {
  const [state, setState] = useState(initial);
  const set = k => v => setState(s => ({
    ...s,
    [k]: v
  }));
  const persist = next => {
    try {
      window.parent?.postMessage({
        type: "__edit_mode_set_keys",
        edits: next
      }, "*");
    } catch (e) {}
  };
  useEffect(() => {
    const t = setTimeout(() => persist(state), 250);
    return () => clearTimeout(t);
  }, [state]);
  useEffect(() => {
    const onMsg = e => {
      const d = e.data;
      if (!d || !d.type) return;
      if (d.type === "__activate_edit_mode") window.__uinBoardShowTweaks?.(true);
      if (d.type === "__deactivate_edit_mode") window.__uinBoardShowTweaks?.(false);
    };
    window.addEventListener("message", onMsg);
    try {
      window.parent?.postMessage({
        type: "__edit_mode_available"
      }, "*");
    } catch (e) {}
    return () => window.removeEventListener("message", onMsg);
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "uin-board-cover"
  }, /*#__PURE__*/React.createElement("img", {
    className: "uin-board-cover-logo",
    src: "../assets/logo-uinsure-white.png",
    alt: "Uinsure"
  }), /*#__PURE__*/React.createElement("div", {
    className: "uin-board-cover-pill"
  }, /*#__PURE__*/React.createElement(BoardEditable, {
    value: state.context,
    onChange: set("context"),
    uppercase: true,
    placeholder: "Context / deck type"
  })), /*#__PURE__*/React.createElement("h1", {
    className: "uin-board-cover-headline"
  }, /*#__PURE__*/React.createElement(BoardEditable, {
    className: "uin-board-cover-headline-aurora",
    value: state.headlineAurora,
    onChange: set("headlineAurora"),
    uppercase: true,
    placeholder: "Headline \u2014 aurora line"
  }), /*#__PURE__*/React.createElement(BoardEditable, {
    className: "uin-board-cover-headline-white",
    value: state.headlineWhite,
    onChange: set("headlineWhite"),
    uppercase: true,
    placeholder: "Headline \u2014 white line (e.g. period)"
  })), /*#__PURE__*/React.createElement("p", {
    className: "uin-board-cover-desc"
  }, /*#__PURE__*/React.createElement(BoardEditable, {
    value: state.description,
    onChange: set("description"),
    placeholder: "One short sentence \u2014 what the pack covers"
  })), /*#__PURE__*/React.createElement("div", {
    className: "uin-board-cover-meta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "uin-board-cover-date"
  }, /*#__PURE__*/React.createElement(BoardEditable, {
    value: state.date,
    onChange: set("date"),
    uppercase: true,
    placeholder: "Meeting date"
  })), /*#__PURE__*/React.createElement("div", {
    className: "uin-board-cover-classify"
  }, /*#__PURE__*/React.createElement(BoardEditable, {
    value: state.classification,
    onChange: set("classification"),
    uppercase: true,
    placeholder: "Classification line"
  }))), /*#__PURE__*/React.createElement(BoardTweaksPanel, {
    state: state,
    setState: setState
  }));
};
function BoardTweaksPanel({
  state,
  setState
}) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    window.__uinBoardShowTweaks = setOpen;
    return () => {
      delete window.__uinBoardShowTweaks;
    };
  }, []);
  if (!open) return null;
  const set = k => e => setState(s => ({
    ...s,
    [k]: e.target.value
  }));
  const row = {
    display: "flex",
    flexDirection: "column",
    gap: 4,
    marginBottom: 12
  };
  const label = {
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: 0.04,
    color: "#5C5C5C",
    textTransform: "uppercase"
  };
  const input = {
    fontFamily: "Proxima Nova, system-ui, sans-serif",
    fontSize: 13,
    padding: "8px 10px",
    border: "1px solid #E5E5E5",
    borderRadius: 8,
    outline: "none",
    color: "#331047",
    background: "#fff"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: 20,
      bottom: 20,
      width: 320,
      background: "#fff",
      color: "#331047",
      border: "1px solid #E5E5E5",
      borderRadius: 16,
      boxShadow: "0 20px 48px rgba(51,16,71,0.22)",
      padding: 18,
      zIndex: 9999,
      fontFamily: "Proxima Nova, system-ui, sans-serif"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 15,
      letterSpacing: -0.01
    }
  }, "Tweaks \u2014 Board cover"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(false),
    style: {
      border: 0,
      background: "transparent",
      fontSize: 18,
      cursor: "pointer",
      color: "#5C5C5C"
    },
    "aria-label": "Close"
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Context pill"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.context,
    onChange: set("context")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Headline \u2014 aurora line"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.headlineAurora,
    onChange: set("headlineAurora")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Headline \u2014 white line"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.headlineWhite,
    onChange: set("headlineWhite")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Description"), /*#__PURE__*/React.createElement("textarea", {
    style: {
      ...input,
      resize: "vertical",
      minHeight: 60
    },
    value: state.description,
    onChange: set("description")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Meeting date"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.date,
    onChange: set("date")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Classification line"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.classification,
    onChange: set("classification")
  })));
}
window.BoardTitleSlide = BoardTitleSlide;
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/BoardTitleSlide.jsx", error: String((e && e.message) || e) }); }

// slides/TitleSlide.jsx
try { (() => {
/*
 * TitleSlide — Uinsure master title slide (reference-locked layout).
 * All copy is editable in two ways:
 *   (1) Click any text in the slide to edit in place.
 *   (2) Toggle Tweaks in the toolbar to open a side panel with the same fields.
 * Values persist to disk via __edit_mode_set_keys so reload keeps your copy.
 */
const {
  useState,
  useEffect,
  useRef
} = React;

/* Default content — can be edited live, not baked into the design. */
const TITLE_DEFAULTS = /*EDITMODE-BEGIN*/{
  "category": "BOARD DECISION — 18 MAY 2026",
  "headlineAurora": "LONG TERM STRATEGY",
  "headlineWhite": "AND LEADERSHIP CONFIDENCE",
  "description": "Insert the description of the deck here",
  "date": "19 / 04 / 2026"
} /*EDITMODE-END*/;

/* Small helper: a contentEditable span that publishes changes up. */
function Editable({
  value,
  onChange,
  className,
  style,
  uppercase = false,
  placeholder
}) {
  const ref = useRef(null);
  // Sync external value → DOM only when it differs, to avoid caret jumps.
  useEffect(() => {
    if (ref.current && ref.current.textContent !== value) {
      ref.current.textContent = value;
    }
  }, [value]);
  return /*#__PURE__*/React.createElement("span", {
    ref: ref,
    className: className,
    style: {
      ...style,
      textTransform: uppercase ? "uppercase" : undefined,
      outline: "none",
      cursor: "text"
    },
    contentEditable: true,
    suppressContentEditableWarning: true,
    spellCheck: false,
    "data-placeholder": placeholder,
    onInput: e => onChange(e.currentTarget.textContent || ""),
    onKeyDown: e => {
      if (e.key === "Enter") {
        e.preventDefault();
        e.currentTarget.blur();
      }
    }
  });
}
const TitleSlide = ({
  initial = TITLE_DEFAULTS
} = {}) => {
  const [state, setState] = useState(initial);
  const set = k => v => setState(s => ({
    ...s,
    [k]: v
  }));

  // Persist to disk so reload keeps the current copy.
  const persist = next => {
    try {
      window.parent?.postMessage({
        type: "__edit_mode_set_keys",
        edits: next
      }, "*");
    } catch (e) {/* ignore */}
  };
  useEffect(() => {
    const t = setTimeout(() => persist(state), 250);
    return () => clearTimeout(t);
  }, [state]);

  // Expose a Tweaks panel with the same fields.
  useEffect(() => {
    const onMsg = e => {
      const d = e.data;
      if (!d || !d.type) return;
      if (d.type === "__activate_edit_mode") window.__uinShowTweaks?.(true);
      if (d.type === "__deactivate_edit_mode") window.__uinShowTweaks?.(false);
    };
    window.addEventListener("message", onMsg);
    try {
      window.parent?.postMessage({
        type: "__edit_mode_available"
      }, "*");
    } catch (e) {}
    return () => window.removeEventListener("message", onMsg);
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    className: "uin-title-slide"
  }, /*#__PURE__*/React.createElement("img", {
    className: "uin-title-bg",
    src: "../assets/brand-background-u.jpg",
    alt: "",
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("img", {
    className: "uin-title-logo",
    src: "../assets/logo-uinsure-white.png",
    alt: "Uinsure"
  }), /*#__PURE__*/React.createElement("div", {
    className: "uin-title-pill"
  }, /*#__PURE__*/React.createElement(Editable, {
    value: state.category,
    onChange: set("category"),
    uppercase: true,
    placeholder: "Category / context"
  })), /*#__PURE__*/React.createElement("h1", {
    className: "uin-title-headline"
  }, /*#__PURE__*/React.createElement(Editable, {
    className: "uin-title-headline-aurora",
    value: state.headlineAurora,
    onChange: set("headlineAurora"),
    uppercase: true,
    placeholder: "Highlighted phrase"
  }), " ", /*#__PURE__*/React.createElement(Editable, {
    className: "uin-title-headline-white",
    value: state.headlineWhite,
    onChange: set("headlineWhite"),
    uppercase: true,
    placeholder: "Remainder of headline"
  })), /*#__PURE__*/React.createElement("p", {
    className: "uin-title-desc"
  }, /*#__PURE__*/React.createElement("span", {
    className: "uin-title-bullet",
    "aria-hidden": "true"
  }, "\u25AA"), /*#__PURE__*/React.createElement(Editable, {
    value: state.description,
    onChange: set("description"),
    placeholder: "One-line description of the deck"
  })), /*#__PURE__*/React.createElement("div", {
    className: "uin-title-date"
  }, /*#__PURE__*/React.createElement(Editable, {
    value: state.date,
    onChange: set("date"),
    placeholder: "Date"
  })), /*#__PURE__*/React.createElement(TweaksPanel, {
    state: state,
    setState: setState
  }));
};

/* Floating Tweaks panel — hidden until the toolbar toggle turns it on. */
function TweaksPanel({
  state,
  setState
}) {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    window.__uinShowTweaks = setOpen;
    return () => {
      delete window.__uinShowTweaks;
    };
  }, []);
  if (!open) return null;
  const set = k => e => setState(s => ({
    ...s,
    [k]: e.target.value
  }));
  const row = {
    display: "flex",
    flexDirection: "column",
    gap: 4,
    marginBottom: 12
  };
  const label = {
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: 0.04,
    color: "#6B5E7A",
    textTransform: "uppercase"
  };
  const input = {
    fontFamily: "Proxima Nova, system-ui, sans-serif",
    fontSize: 13,
    padding: "8px 10px",
    border: "1px solid #E7E2EC",
    borderRadius: 8,
    outline: "none",
    color: "#331047",
    background: "#fff"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      right: 20,
      bottom: 20,
      width: 320,
      background: "#fff",
      color: "#331047",
      border: "1px solid #E7E2EC",
      borderRadius: 16,
      boxShadow: "0 20px 48px rgba(51,16,71,0.22)",
      padding: 18,
      zIndex: 9999,
      fontFamily: "Proxima Nova, system-ui, sans-serif"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 15,
      letterSpacing: -0.01
    }
  }, "Tweaks"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(false),
    style: {
      border: 0,
      background: "transparent",
      fontSize: 18,
      cursor: "pointer",
      color: "#6B5E7A"
    },
    "aria-label": "Close"
  }, "\xD7")), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Category pill"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.category,
    onChange: set("category")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Headline \u2014 aurora"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.headlineAurora,
    onChange: set("headlineAurora")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Headline \u2014 white"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.headlineWhite,
    onChange: set("headlineWhite")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Description"), /*#__PURE__*/React.createElement("textarea", {
    style: {
      ...input,
      resize: "vertical",
      minHeight: 60
    },
    value: state.description,
    onChange: set("description")
  })), /*#__PURE__*/React.createElement("div", {
    style: row
  }, /*#__PURE__*/React.createElement("span", {
    style: label
  }, "Date"), /*#__PURE__*/React.createElement("input", {
    style: input,
    value: state.date,
    onChange: set("date")
  })));
}
window.TitleSlide = TitleSlide;
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/TitleSlide.jsx", error: String((e && e.message) || e) }); }

// slides/deck-stage.js
try { (() => {
/**
 * <deck-stage> — reusable web component for HTML decks.
 *
 * Handles:
 *  (a) speaker notes — reads <script type="application/json" id="speaker-notes">
 *      and posts {slideIndexChanged: N} to the parent window on nav.
 *  (b) keyboard navigation — ←/→, PgUp/PgDn, Space, Home/End, number keys.
 *  (c) press R to reset to slide 0 (with a tasteful keyboard hint).
 *  (d) bottom-center overlay showing slide count + hints, fades out on idle.
 *  (e) auto-scaling — inner canvas is a fixed design size (default 1920×1080)
 *      scaled with `transform: scale()` to fit the viewport, letterboxed.
 *      Set the `noscale` attribute to render at authored size (1:1) — the
 *      PPTX exporter sets this so its DOM capture sees unscaled geometry.
 *  (f) print — `@media print` lays every slide out as its own page at the
 *      design size, so the browser's Print → Save as PDF produces a clean
 *      one-page-per-slide PDF with no extra setup.
 *
 * Slides are HIDDEN, not unmounted. Non-active slides stay in the DOM with
 * `visibility: hidden` + `opacity: 0`, so their state (videos, iframes,
 * form inputs, React trees) is preserved across navigation.
 *
 * Lifecycle event — the component dispatches a `slidechange` CustomEvent on
 * itself whenever the active slide changes (including the initial mount).
 * The event bubbles and composes out of shadow DOM, so you can listen on
 * the <deck-stage> element or on document:
 *
 *   document.querySelector('deck-stage').addEventListener('slidechange', (e) => {
 *     e.detail.index         // new 0-based index
 *     e.detail.previousIndex // previous index, or -1 on init
 *     e.detail.total         // total slide count
 *     e.detail.slide         // the new active slide element
 *     e.detail.previousSlide // the prior slide element, or null on init
 *     e.detail.reason        // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
 *   });
 *
 * Persistence: current slide index is saved to localStorage keyed by the
 * document path, so refresh returns you to the same place.
 *
 * Usage:
 *   <deck-stage width="1920" height="1080">
 *     <section data-label="Title">...</section>
 *     <section data-label="Agenda">...</section>
 *   </deck-stage>
 *
 * Slides are the direct element children of <deck-stage>. Each slide is
 * automatically tagged with:
 *   - data-screen-label="NN Label"   (1-indexed, for comment flow)
 *   - data-om-validate="no_overflowing_text,no_overlapping_text,slide_sized_text"
 */

(() => {
  const DESIGN_W_DEFAULT = 1920;
  const DESIGN_H_DEFAULT = 1080;
  const STORAGE_PREFIX = 'deck-stage:slide:';
  const OVERLAY_HIDE_MS = 1800;
  const VALIDATE_ATTR = 'no_overflowing_text,no_overlapping_text,slide_sized_text';
  const pad2 = n => String(n).padStart(2, '0');
  const stylesheet = `
    :host {
      position: fixed;
      inset: 0;
      display: block;
      background: #000;
      color: #fff;
      font-family: -apple-system, BlinkMacSystemFont, "Helvetica Neue", Helvetica, Arial, sans-serif;
      overflow: hidden;
    }

    .stage {
      position: absolute;
      inset: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .canvas {
      position: relative;
      transform-origin: center center;
      flex-shrink: 0;
      background: #fff;
      will-change: transform;
    }

    /* Slides live in light DOM (via <slot>) so authored CSS still applies.
       We absolutely position each slotted child to stack them. */
    ::slotted(*) {
      position: absolute !important;
      inset: 0 !important;
      width: 100% !important;
      height: 100% !important;
      box-sizing: border-box !important;
      overflow: hidden;
      opacity: 0;
      pointer-events: none;
      visibility: hidden;
    }
    ::slotted([data-deck-active]) {
      opacity: 1;
      pointer-events: auto;
      visibility: visible;
    }

    /* Tap zones for mobile — back/forward thirds like Stories.
       Transparent, no visible UI, don't block the overlay. */
    .tapzones {
      position: fixed;
      inset: 0;
      display: flex;
      z-index: 2147482000;
      pointer-events: none;
    }
    .tapzone {
      flex: 1;
      pointer-events: auto;
      -webkit-tap-highlight-color: transparent;
    }
    /* Only activate tap zones on coarse pointers (touch devices). */
    @media (hover: hover) and (pointer: fine) {
      .tapzones { display: none; }
    }

    .overlay {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translate(-50%, 6px) scale(0.92);
      filter: blur(6px);
      display: flex;
      align-items: center;
      gap: 4px;
      padding: 4px;
      background: #000;
      color: #fff;
      border-radius: 999px;
      font-size: 12px;
      font-feature-settings: "tnum" 1;
      letter-spacing: 0.01em;
      opacity: 0;
      pointer-events: none;
      transition: opacity 260ms ease, transform 260ms cubic-bezier(.2,.8,.2,1), filter 260ms ease;
      transform-origin: center bottom;
      z-index: 2147483000;
      user-select: none;
    }
    .overlay[data-visible] {
      opacity: 1;
      pointer-events: auto;
      transform: translate(-50%, 0) scale(1);
      filter: blur(0);
    }

    .btn {
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 0;
      margin: 0;
      padding: 0;
      color: inherit;
      font: inherit;
      cursor: default;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      height: 28px;
      min-width: 28px;
      border-radius: 999px;
      color: rgba(255,255,255,0.72);
      transition: background 140ms ease, color 140ms ease;
      -webkit-tap-highlight-color: transparent;
    }
    .btn:hover { background: rgba(255,255,255,0.12); color: #fff; }
    .btn:active { background: rgba(255,255,255,0.18); }
    .btn:focus { outline: none; }
    .btn:focus-visible { outline: none; }
    .btn::-moz-focus-inner { border: 0; }
    .btn svg { width: 14px; height: 14px; display: block; }
    .btn.reset {
      font-size: 11px;
      font-weight: 500;
      letter-spacing: 0.02em;
      padding: 0 10px 0 12px;
      gap: 6px;
      color: rgba(255,255,255,0.72);
    }
    .btn.reset .kbd {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 16px;
      height: 16px;
      padding: 0 4px;
      font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
      font-size: 10px;
      line-height: 1;
      color: rgba(255,255,255,0.88);
      background: rgba(255,255,255,0.12);
      border-radius: 4px;
    }

    .count {
      font-variant-numeric: tabular-nums;
      color: #fff;
      font-weight: 500;
      padding: 0 8px;
      min-width: 42px;
      text-align: center;
      font-size: 12px;
    }
    .count .sep { color: rgba(255,255,255,0.45); margin: 0 3px; font-weight: 400; }
    .count .total { color: rgba(255,255,255,0.55); }

    .divider {
      width: 1px;
      height: 14px;
      background: rgba(255,255,255,0.18);
      margin: 0 2px;
    }

    /* ── Print: one page per slide, no chrome ────────────────────────────
       The screen layout stacks every slide at inset:0 inside a scaled
       canvas; for print we want them in document flow at the authored
       design size so the browser paginates one slide per sheet. The
       @page size is set from the width/height attributes via the inline
       <style id="deck-stage-print-page"> that connectedCallback injects
       into <head> (the @page at-rule has no effect inside shadow DOM). */
    @media print {
      :host {
        position: static;
        inset: auto;
        background: none;
        overflow: visible;
        color: inherit;
      }
      .stage { position: static; display: block; }
      .canvas {
        transform: none !important;
        width: auto !important;
        height: auto !important;
        background: none;
        will-change: auto;
      }
      ::slotted(*) {
        position: relative !important;
        inset: auto !important;
        width: var(--deck-design-w) !important;
        height: var(--deck-design-h) !important;
        box-sizing: border-box !important;
        opacity: 1 !important;
        visibility: visible !important;
        pointer-events: auto;
        break-after: page;
        page-break-after: always;
        break-inside: avoid;
        overflow: hidden;
      }
      ::slotted(*:last-child) {
        break-after: auto;
        page-break-after: auto;
      }
      .overlay, .tapzones { display: none !important; }
    }
  `;
  class DeckStage extends HTMLElement {
    static get observedAttributes() {
      return ['width', 'height', 'noscale'];
    }
    constructor() {
      super();
      this._root = this.attachShadow({
        mode: 'open'
      });
      this._index = 0;
      this._slides = [];
      this._notes = [];
      this._hideTimer = null;
      this._mouseIdleTimer = null;
      this._storageKey = STORAGE_PREFIX + (location.pathname || '/');
      this._onKey = this._onKey.bind(this);
      this._onResize = this._onResize.bind(this);
      this._onSlotChange = this._onSlotChange.bind(this);
      this._onMouseMove = this._onMouseMove.bind(this);
      this._onTapBack = this._onTapBack.bind(this);
      this._onTapForward = this._onTapForward.bind(this);
    }
    get designWidth() {
      return parseInt(this.getAttribute('width'), 10) || DESIGN_W_DEFAULT;
    }
    get designHeight() {
      return parseInt(this.getAttribute('height'), 10) || DESIGN_H_DEFAULT;
    }
    connectedCallback() {
      this._render();
      this._loadNotes();
      this._syncPrintPageRule();
      window.addEventListener('keydown', this._onKey);
      window.addEventListener('resize', this._onResize);
      window.addEventListener('mousemove', this._onMouseMove, {
        passive: true
      });
      // Initial collection + layout happens via slotchange, which fires on mount.
    }
    disconnectedCallback() {
      window.removeEventListener('keydown', this._onKey);
      window.removeEventListener('resize', this._onResize);
      window.removeEventListener('mousemove', this._onMouseMove);
      if (this._hideTimer) clearTimeout(this._hideTimer);
      if (this._mouseIdleTimer) clearTimeout(this._mouseIdleTimer);
    }
    attributeChangedCallback() {
      if (this._canvas) {
        this._canvas.style.width = this.designWidth + 'px';
        this._canvas.style.height = this.designHeight + 'px';
        this._canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
        this._canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
        this._fit();
        this._syncPrintPageRule();
      }
    }
    _render() {
      const style = document.createElement('style');
      style.textContent = stylesheet;
      const stage = document.createElement('div');
      stage.className = 'stage';
      const canvas = document.createElement('div');
      canvas.className = 'canvas';
      canvas.style.width = this.designWidth + 'px';
      canvas.style.height = this.designHeight + 'px';
      canvas.style.setProperty('--deck-design-w', this.designWidth + 'px');
      canvas.style.setProperty('--deck-design-h', this.designHeight + 'px');
      const slot = document.createElement('slot');
      slot.addEventListener('slotchange', this._onSlotChange);
      canvas.appendChild(slot);
      stage.appendChild(canvas);

      // Tap zones (mobile): left third = back, right third = forward.
      const tapzones = document.createElement('div');
      tapzones.className = 'tapzones export-hidden';
      tapzones.setAttribute('aria-hidden', 'true');
      const tzBack = document.createElement('div');
      tzBack.className = 'tapzone tapzone--back';
      const tzMid = document.createElement('div');
      tzMid.className = 'tapzone tapzone--mid';
      tzMid.style.pointerEvents = 'none';
      const tzFwd = document.createElement('div');
      tzFwd.className = 'tapzone tapzone--fwd';
      tzBack.addEventListener('click', this._onTapBack);
      tzFwd.addEventListener('click', this._onTapForward);
      tapzones.append(tzBack, tzMid, tzFwd);

      // Overlay: compact, solid black, with clickable controls.
      const overlay = document.createElement('div');
      overlay.className = 'overlay export-hidden';
      overlay.setAttribute('role', 'toolbar');
      overlay.setAttribute('aria-label', 'Deck controls');
      overlay.innerHTML = `
        <button class="btn prev" type="button" aria-label="Previous slide" title="Previous (←)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 3L5 8l5 5"/></svg>
        </button>
        <span class="count" aria-live="polite"><span class="current">1</span><span class="sep">/</span><span class="total">1</span></span>
        <button class="btn next" type="button" aria-label="Next slide" title="Next (→)">
          <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 3l5 5-5 5"/></svg>
        </button>
        <span class="divider"></span>
        <button class="btn reset" type="button" aria-label="Reset to first slide" title="Reset (R)">Reset<span class="kbd">R</span></button>
      `;
      overlay.querySelector('.prev').addEventListener('click', () => this._go(this._index - 1, 'click'));
      overlay.querySelector('.next').addEventListener('click', () => this._go(this._index + 1, 'click'));
      overlay.querySelector('.reset').addEventListener('click', () => this._go(0, 'click'));
      this._root.append(style, stage, tapzones, overlay);
      this._canvas = canvas;
      this._slot = slot;
      this._overlay = overlay;
      this._countEl = overlay.querySelector('.current');
      this._totalEl = overlay.querySelector('.total');
    }

    /** @page must live in the document stylesheet — it's a no-op inside
     *  shadow DOM. Inject/update a single <head> style tag so the print
     *  sheet matches the design size and Save-as-PDF yields one slide per
     *  page with no margins. */
    _syncPrintPageRule() {
      const id = 'deck-stage-print-page';
      let tag = document.getElementById(id);
      if (!tag) {
        tag = document.createElement('style');
        tag.id = id;
        document.head.appendChild(tag);
      }
      tag.textContent = '@page { size: ' + this.designWidth + 'px ' + this.designHeight + 'px; margin: 0; } ' + '@media print { html, body { margin: 0 !important; padding: 0 !important; background: none !important; overflow: visible !important; height: auto !important; } ' + '* { -webkit-print-color-adjust: exact; print-color-adjust: exact; } }';
    }
    _onSlotChange() {
      this._collectSlides();
      this._restoreIndex();
      this._applyIndex({
        showOverlay: false,
        broadcast: true,
        reason: 'init'
      });
      this._fit();
    }
    _collectSlides() {
      const assigned = this._slot.assignedElements({
        flatten: true
      });
      this._slides = assigned.filter(el => {
        // Skip template/style/script nodes even if someone slots them.
        const tag = el.tagName;
        return tag !== 'TEMPLATE' && tag !== 'SCRIPT' && tag !== 'STYLE';
      });
      this._slides.forEach((slide, i) => {
        const n = i + 1;
        // Determine a label for comment flow: prefer explicit data-label,
        // then an existing data-screen-label, then first heading, else "Slide".
        let label = slide.getAttribute('data-label');
        if (!label) {
          const existing = slide.getAttribute('data-screen-label');
          if (existing) {
            // Strip any leading number the author may have included.
            label = existing.replace(/^\s*\d+\s*/, '').trim() || existing;
          }
        }
        if (!label) {
          const h = slide.querySelector('h1, h2, h3, [data-title]');
          if (h) label = (h.textContent || '').trim().slice(0, 40);
        }
        if (!label) label = 'Slide';
        slide.setAttribute('data-screen-label', `${pad2(n)} ${label}`);

        // Validation attribute for comment flow / auto-checks.
        if (!slide.hasAttribute('data-om-validate')) {
          slide.setAttribute('data-om-validate', VALIDATE_ATTR);
        }
        slide.setAttribute('data-deck-slide', String(i));
      });
      if (this._totalEl) this._totalEl.textContent = String(this._slides.length || 1);
      if (this._index >= this._slides.length) this._index = Math.max(0, this._slides.length - 1);
    }
    _loadNotes() {
      const tag = document.getElementById('speaker-notes');
      if (!tag) {
        this._notes = [];
        return;
      }
      try {
        const parsed = JSON.parse(tag.textContent || '[]');
        if (Array.isArray(parsed)) this._notes = parsed;
      } catch (e) {
        console.warn('[deck-stage] Failed to parse #speaker-notes JSON:', e);
        this._notes = [];
      }
    }
    _restoreIndex() {
      try {
        const raw = localStorage.getItem(this._storageKey);
        if (raw != null) {
          const n = parseInt(raw, 10);
          if (Number.isFinite(n) && n >= 0 && n < this._slides.length) {
            this._index = n;
          }
        }
      } catch (e) {/* ignore */}
    }
    _persistIndex() {
      try {
        localStorage.setItem(this._storageKey, String(this._index));
      } catch (e) {/* ignore */}
    }
    _applyIndex({
      showOverlay = true,
      broadcast = true,
      reason = 'init'
    } = {}) {
      if (!this._slides.length) return;
      const prev = this._prevIndex == null ? -1 : this._prevIndex;
      const curr = this._index;
      this._slides.forEach((s, i) => {
        if (i === curr) s.setAttribute('data-deck-active', '');else s.removeAttribute('data-deck-active');
      });
      if (this._countEl) this._countEl.textContent = String(curr + 1);
      this._persistIndex();
      if (broadcast) {
        // (1) Legacy: host-window postMessage for speaker-notes renderers.
        try {
          window.postMessage({
            slideIndexChanged: curr
          }, '*');
        } catch (e) {}

        // (2) In-page CustomEvent on the <deck-stage> element itself.
        //     Bubbles and composes out of shadow DOM so slide code can listen:
        //       document.querySelector('deck-stage').addEventListener('slidechange', e => {
        //         e.detail.index, e.detail.previousIndex, e.detail.total, e.detail.slide, e.detail.reason
        //       });
        const detail = {
          index: curr,
          previousIndex: prev,
          total: this._slides.length,
          slide: this._slides[curr] || null,
          previousSlide: prev >= 0 ? this._slides[prev] || null : null,
          reason: reason // 'init' | 'keyboard' | 'click' | 'tap' | 'api'
        };
        this.dispatchEvent(new CustomEvent('slidechange', {
          detail,
          bubbles: true,
          composed: true
        }));
      }
      this._prevIndex = curr;
      if (showOverlay) this._flashOverlay();
    }
    _flashOverlay() {
      if (!this._overlay) return;
      this._overlay.setAttribute('data-visible', '');
      if (this._hideTimer) clearTimeout(this._hideTimer);
      this._hideTimer = setTimeout(() => {
        this._overlay.removeAttribute('data-visible');
      }, OVERLAY_HIDE_MS);
    }
    _fit() {
      if (!this._canvas) return;
      // PPTX export sets noscale so the DOM capture sees authored-size
      // geometry — the scaled canvas is in shadow DOM, so the exporter's
      // resetTransformSelector can't reach .canvas.style.transform directly.
      if (this.hasAttribute('noscale')) {
        this._canvas.style.transform = 'none';
        return;
      }
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const s = Math.min(vw / this.designWidth, vh / this.designHeight);
      this._canvas.style.transform = `scale(${s})`;
    }
    _onResize() {
      this._fit();
    }
    _onMouseMove() {
      // Keep overlay visible while mouse moves; hide after idle.
      this._flashOverlay();
    }
    _onTapBack(e) {
      e.preventDefault();
      this._go(this._index - 1, 'tap');
    }
    _onTapForward(e) {
      e.preventDefault();
      this._go(this._index + 1, 'tap');
    }
    _onKey(e) {
      // Ignore when the user is typing.
      const t = e.target;
      if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const key = e.key;
      let handled = true;
      if (key === 'ArrowRight' || key === 'PageDown' || key === ' ' || key === 'Spacebar') {
        this._go(this._index + 1, 'keyboard');
      } else if (key === 'ArrowLeft' || key === 'PageUp') {
        this._go(this._index - 1, 'keyboard');
      } else if (key === 'Home') {
        this._go(0, 'keyboard');
      } else if (key === 'End') {
        this._go(this._slides.length - 1, 'keyboard');
      } else if (key === 'r' || key === 'R') {
        this._go(0, 'keyboard');
      } else if (/^[0-9]$/.test(key)) {
        // 1..9 jump to that slide; 0 jumps to 10.
        const n = key === '0' ? 9 : parseInt(key, 10) - 1;
        if (n < this._slides.length) this._go(n, 'keyboard');
      } else {
        handled = false;
      }
      if (handled) {
        e.preventDefault();
        this._flashOverlay();
      }
    }
    _go(i, reason = 'api') {
      if (!this._slides.length) return;
      const clamped = Math.max(0, Math.min(this._slides.length - 1, i));
      if (clamped === this._index) {
        this._flashOverlay();
        return;
      }
      this._index = clamped;
      this._applyIndex({
        showOverlay: true,
        broadcast: true,
        reason
      });
    }

    // Public API ------------------------------------------------------------

    /** Current slide index (0-based). */
    get index() {
      return this._index;
    }
    /** Total slide count. */
    get length() {
      return this._slides.length;
    }
    /** Programmatically navigate. */
    goTo(i) {
      this._go(i, 'api');
    }
    next() {
      this._go(this._index + 1, 'api');
    }
    prev() {
      this._go(this._index - 1, 'api');
    }
    reset() {
      this._go(0, 'api');
    }
  }
  if (!customElements.get('deck-stage')) {
    customElements.define('deck-stage', DeckStage);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "slides/deck-stage.js", error: String((e && e.message) || e) }); }

// ui_kits/marketing/components.jsx
try { (() => {
const {
  useState
} = React;
function Nav() {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 10,
      background: '#fff',
      borderBottom: '1px solid #E7E7E7'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      padding: '16px 28px',
      display: 'flex',
      alignItems: 'center',
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-uinsure-amethyst.png",
    alt: "Uinsure",
    style: {
      height: 28
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 26,
      marginLeft: 20,
      flex: 1
    }
  }, ['Home Insurance', 'Landlord', 'Specialist', 'Claims', 'Help'].map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    href: "#",
    style: {
      color: '#331047',
      textDecoration: 'none',
      fontWeight: 600,
      fontSize: 14
    }
  }, l))), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: '#331047',
      fontWeight: 600,
      fontSize: 14,
      textDecoration: 'none'
    }
  }, "For advisers"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: '#23F3A1',
      color: '#331047',
      border: 0,
      borderRadius: 999,
      padding: '10px 20px',
      fontWeight: 800,
      fontSize: 14,
      fontFamily: 'inherit',
      cursor: 'pointer',
      boxShadow: '0 6px 18px rgba(35,243,161,0.3)'
    }
  }, "Get a quote")));
}
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      background: '#331047',
      color: '#fff',
      overflow: 'hidden',
      padding: '100px 28px 120px',
      backgroundImage: 'url(../../assets/brand-background-u.jpg)',
      backgroundSize: 'cover',
      backgroundPosition: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      position: 'relative',
      display: 'grid',
      gridTemplateColumns: '1.3fr 1fr',
      gap: 64,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      padding: '6px 14px',
      background: 'rgba(255,255,255,0.1)',
      borderRadius: 999,
      fontSize: 12,
      fontWeight: 800,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: '#23F3A1'
    }
  }), "5 Star Defaqto rated \xB7 10 years running"), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/headline-insurance-was-complicated-white.png",
    alt: "Insurance was complicated. We redesigned it.",
    style: {
      display: 'block',
      width: '100%',
      maxWidth: 540,
      height: 'auto',
      margin: '0 0 8px'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 300,
      fontSize: 20,
      lineHeight: 1.5,
      marginTop: 22,
      maxWidth: 520,
      opacity: 0.9
    }
  }, "We compare premiums from a panel of leading UK insurers so you get a competitive home insurance quote in under a minute."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      marginTop: 30
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: '#23F3A1',
      color: '#331047',
      border: 0,
      borderRadius: 999,
      padding: '16px 28px',
      fontWeight: 800,
      fontSize: 16,
      fontFamily: 'inherit',
      cursor: 'pointer',
      boxShadow: '0 8px 24px rgba(35,243,161,0.35)'
    }
  }, "Get a quote"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'transparent',
      color: '#fff',
      border: '1.5px solid rgba(255,255,255,0.35)',
      borderRadius: 999,
      padding: '16px 24px',
      fontWeight: 800,
      fontSize: 16,
      fontFamily: 'inherit',
      cursor: 'pointer'
    }
  }, "Make a claim"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      color: '#331047',
      borderRadius: 24,
      padding: 28,
      boxShadow: '0 40px 80px rgba(0,0,0,0.35)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 12,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: '#6B5E7A'
    }
  }, "Quick quote"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 24,
      margin: '6px 0 18px'
    }
  }, "Where's your home?"), /*#__PURE__*/React.createElement("label", {
    style: {
      fontWeight: 800,
      fontSize: 11,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      color: '#6B5E7A'
    }
  }, "Postcode"), /*#__PURE__*/React.createElement("input", {
    defaultValue: "M3 3AQ",
    style: {
      width: '100%',
      padding: '14px 16px',
      border: '1.5px solid #E7E7E7',
      borderRadius: 12,
      fontFamily: 'inherit',
      fontSize: 16,
      fontWeight: 300,
      marginTop: 6,
      marginBottom: 14,
      boxSizing: 'border-box'
    }
  }), /*#__PURE__*/React.createElement("button", {
    style: {
      width: '100%',
      background: '#23F3A1',
      color: '#331047',
      border: 0,
      borderRadius: 12,
      padding: '14px',
      fontWeight: 800,
      fontSize: 16,
      fontFamily: 'inherit',
      cursor: 'pointer'
    }
  }, "Start my quote"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 300,
      fontSize: 12,
      color: '#6B5E7A',
      marginTop: 10,
      textAlign: 'center'
    }
  }, "Takes under a minute \xB7 No card needed"))));
}
function StatsStrip() {
  const stats = [{
    n: '650k+',
    l: 'Homes protected'
  }, {
    n: '10 yrs',
    l: '5-Star Defaqto rated'
  }, {
    n: '<1 min',
    l: 'To get a quote'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'linear-gradient(135deg,#331047 0%,#2D1A4C 50%,#8F75DF 100%)',
      color: '#fff',
      padding: '56px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 40,
      textAlign: 'center'
    }
  }, stats.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.l
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 64,
      lineHeight: 1,
      letterSpacing: '-0.02em'
    }
  }, s.n), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14,
      letterSpacing: '0.08em',
      textTransform: 'uppercase',
      opacity: 0.8,
      marginTop: 8
    }
  }, s.l)))));
}
function BenefitRail() {
  const items = [{
    ic: '../../assets/icons/circled/icon-37.png',
    t: '5-Star rated',
    d: 'Defaqto 5-Star for 10 consecutive years.'
  }, {
    ic: '../../assets/icons/circled/icon-44.png',
    t: 'Quote fast',
    d: 'The whole panel compared in under a minute.'
  }, {
    ic: '../../assets/icons/circled/icon-47.png',
    t: 'Proper cover',
    d: 'High limits, low excess, transparent fees.'
  }, {
    ic: '../../assets/icons/circled/icon-36.png',
    t: 'Here 24/7',
    d: 'UK based claims team, every day of the year.'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: '#fff',
      padding: '96px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 12,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: '#331047'
    }
  }, "Why Uinsure"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontWeight: 900,
      fontSize: 44,
      lineHeight: 1.05,
      color: '#331047',
      marginTop: 8,
      marginBottom: 48,
      maxWidth: 680,
      textWrap: 'balance',
      letterSpacing: '-0.01em'
    }
  }, "We've always treated loyalty like royalty."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 24
    }
  }, items.map(i => /*#__PURE__*/React.createElement("div", {
    key: i.t,
    style: {
      background: '#fff',
      borderRadius: 20,
      padding: 24,
      boxShadow: '0 8px 24px rgba(51,16,71,0.08)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: i.ic,
    style: {
      width: 52,
      height: 52,
      color: '#331047',
      marginBottom: 14
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 900,
      fontSize: 18,
      color: '#331047',
      marginBottom: 6
    }
  }, i.t), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 300,
      fontSize: 14,
      color: '#6B5E7A',
      lineHeight: 1.5
    }
  }, i.d))))));
}
function AdviserCTA() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'linear-gradient(135deg,#8F75DF 0%,#D3C4EB 100%)',
      padding: '80px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr',
      gap: 48,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 12,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: '#331047'
    }
  }, "For Financial Advisers"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontWeight: 900,
      fontSize: 48,
      lineHeight: 1.05,
      color: '#331047',
      marginTop: 10,
      marginBottom: 16,
      letterSpacing: '-0.01em'
    }
  }, "Refer to us, or quote it yourself."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 300,
      fontSize: 18,
      color: '#331047',
      maxWidth: 560,
      lineHeight: 1.5,
      opacity: 0.85
    }
  }, "Access the Uinsure Adviser Platform to quote, submit and manage clients' home and specialist policies \u2014 all in one place.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: '#331047',
      color: '#fff',
      border: 0,
      borderRadius: 999,
      padding: '16px 28px',
      fontWeight: 800,
      fontSize: 16,
      fontFamily: 'inherit',
      cursor: 'pointer'
    }
  }, "Open Adviser Platform"), /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'transparent',
      color: '#331047',
      border: '1.5px solid #331047',
      borderRadius: 999,
      padding: '16px 28px',
      fontWeight: 800,
      fontSize: 16,
      fontFamily: 'inherit',
      cursor: 'pointer'
    }
  }, "Book a demo"))));
}
function FAQ() {
  const qs = [{
    q: 'How quickly can I get a quote?',
    a: 'Under one minute. We ask a handful of questions about your home, compare our panel, and show you our best price.'
  }, {
    q: 'Who underwrites my policy?',
    a: 'Policies are underwritten by a panel including Ageas, Allianz, Covéa and RSA. Your schedule will clearly show which insurer covers you.'
  }, {
    q: 'Is there a cancellation fee?',
    a: "We're transparent — we don't charge cancellation or adjustment fees. Cancel within 14 days of your policy starting and we'll give you a full refund."
  }, {
    q: 'Do you auto-renew?',
    a: "Yes, to keep you covered. You can opt out any time — email optout@uinsure.co.uk at least 30 days before renewal."
  }];
  const [open, setOpen] = useState(0);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: '#fff',
      padding: '96px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 860,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontWeight: 900,
      fontSize: 44,
      color: '#331047',
      letterSpacing: '-0.01em',
      marginBottom: 32
    }
  }, "The stuff you want to know"), /*#__PURE__*/React.createElement("div", null, qs.map((item, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      borderTop: '1px solid #E7E7E7'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(open === i ? -1 : i),
    style: {
      width: '100%',
      textAlign: 'left',
      background: 'transparent',
      border: 0,
      padding: '22px 0',
      cursor: 'pointer',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      fontFamily: 'inherit'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 800,
      fontSize: 20,
      color: '#331047'
    }
  }, item.q), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 900,
      fontSize: 22,
      color: '#23F3A1'
    }
  }, open === i ? '–' : '+')), open === i && /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 300,
      fontSize: 16,
      color: '#6B5E7A',
      lineHeight: 1.6,
      paddingBottom: 22,
      maxWidth: 720
    }
  }, item.a))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid #E7E7E7'
    }
  }))));
}
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: '#331047',
      color: '#fff',
      padding: '64px 28px 40px',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 400 440",
    style: {
      position: 'absolute',
      left: -60,
      bottom: -80,
      width: 380,
      opacity: 0.08
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 40 20 L 40 280 C 40 360 100 420 200 420 C 300 420 360 360 360 280 L 360 20 L 280 20 L 280 280 C 280 320 250 340 200 340 C 150 340 120 320 120 280 L 120 20 Z",
    fill: "#fff"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '0 auto',
      position: 'relative',
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr 1fr',
      gap: 48
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-uinsure-white.png",
    style: {
      height: 32,
      marginBottom: 18
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 300,
      fontSize: 14,
      opacity: 0.75,
      maxWidth: 320,
      lineHeight: 1.6
    }
  }, "Home insurance, redesigned. Uinsure Limited is authorised and regulated by the Financial Conduct Authority (FRN 463689).")), [{
    t: 'Products',
    l: ['Home Insurance', 'Landlord', 'Specialist', 'Buy-to-Let']
  }, {
    t: 'Help',
    l: ['Make a claim', 'Policy documents', 'Contact us', 'Complaints']
  }, {
    t: 'Company',
    l: ['About', 'Careers', 'Adviser platform', 'UinsureCX']
  }].map(col => /*#__PURE__*/React.createElement("div", {
    key: col.t
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 12,
      letterSpacing: '0.12em',
      textTransform: 'uppercase',
      color: '#D3C4EB',
      marginBottom: 16
    }
  }, col.t), col.l.map(l => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      fontWeight: 300,
      fontSize: 14,
      opacity: 0.85,
      marginBottom: 10,
      cursor: 'pointer'
    }
  }, l))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1200,
      margin: '48px auto 0',
      paddingTop: 24,
      borderTop: '1px solid rgba(255,255,255,0.15)',
      fontSize: 12,
      fontWeight: 300,
      opacity: 0.6,
      display: 'flex',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, "\xA9 2026 Uinsure Limited. Registered: The XYZ Building, 2 Hardman Street, Manchester M3 3AQ."), /*#__PURE__*/React.createElement("div", null, "Rated Excellent on Trustpilot")));
}
Object.assign(window, {
  Nav,
  Hero,
  StatsStrip,
  BenefitRail,
  AdviserCTA,
  FAQ,
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/marketing/components.jsx", error: String((e && e.message) || e) }); }

})();
